package com.ironhack.businessmodelservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BusinessModelServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BusinessModelServiceApplication.class, args);
	}

}
