package com.ironhack.businessmodelservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BusinessModelServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
